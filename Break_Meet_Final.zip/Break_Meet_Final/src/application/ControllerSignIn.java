package application;

import javafx.scene.control.TextField;
import javafx.scene.image.Image;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ControllerSignIn {
	@FXML
	private Button backButton;

	@FXML
	private AnchorPane sceneSignIn;

	@FXML
	private Button signinButton;

	@FXML
	private TextField idsignin;

	@FXML
	private TextField usersignin;

	@FXML
	private TextField phonesignin;

	@FXML
	private RadioButton malesignin;

	@FXML
	private RadioButton femalesignin;

	@FXML
	private DatePicker datesignin;

	@FXML
	private TextField passsignin;

	@FXML
	Label error1;

	DataBase connection = new DataBase();
	Connection connect;

	ObservableList<Student> student = FXCollections.observableArrayList();

	@FXML
	void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) backButton.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("interFace.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Break Meet");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void AnchorPane() {

	}

	@FXML
	public void sginin() throws IOException, ClassNotFoundException, SQLException {
		error1.setVisible(true);
		connect = connection.connectDB();
		student.clear();

		boolean check = true;

		try {

			String s = "select * from students;";
			Statement stat = connect.createStatement();
			ResultSet rsstudent = stat.executeQuery(s);
			
			while (rsstudent.next()) {
				if (idsignin.getText().equals(String.valueOf(rsstudent.getInt(1)))) {
					check = false;
				}
				student.add(new Student(rsstudent.getInt(1), rsstudent.getString(2), rsstudent.getString(3),
						rsstudent.getString(4), rsstudent.getString(5)));
			}

			rsstudent.close();
			stat.close();

		} catch (Exception E) {

		}

		if (idsignin.getText() == "" || usersignin.getText() == "" || phonesignin.getText() == ""
				|| (malesignin.isSelected() == false && femalesignin.isSelected() == false)
				|| datesignin.getValue().equals(null) || passsignin.getText() == "") {
			error1.setVisible(true);
			error1.setLayoutX(515);
			error1.setLayoutY(359);
			error1.setTextFill(Color.DARKRED);
			error1.setText("error!! the some field is empty");
			error1.setFont(new Font(17));

		} else if (check == false) {

			error1.setVisible(true);
			error1.setLayoutX(515);
			error1.setLayoutY(359);
			error1.setTextFill(Color.DARKRED);
			error1.setText("error!! the User id is used");
			error1.setFont(new Font(17));

		} else if (check == true) {

			DataBase db = new DataBase();
			if (malesignin.isSelected()) {
				db.applyOnDataBase("INSERT INTO students (studentsid,password,studentname,gender,DOfBarth) VALUES ("
						+ idsignin.getText() + ",'" + passsignin.getText() + "','" + usersignin.getText().trim()
						+ "','male','" + datesignin.getValue() + "');");

				db.applyOnDataBase("INSERT INTO phonenumber(studentsid,phonenum)  VALUES (" + idsignin.getText()
						+ ",  '" + phonesignin.getText() + "');");

				connect.close();

				ControllerLogIn.soso = idsignin.getText();
				Stage stage = (Stage) signinButton.getScene().getWindow();
				stage.getIcons().add(new Image("icon.png"));
				stage.close();

				Stage stage1 = new Stage();
				AnchorPane root = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
				stage1.getIcons().add(new Image("icon.png"));
				stage1.setTitle("Basic Interface");
				stage1.setScene(new Scene(root, 846, 473));
				stage1.show();

			} else if (femalesignin.isSelected()) {

				db.applyOnDataBase("INSERT INTO students (studentsid,password,studentname,gender,DOfBarth) VALUES ("
						+ idsignin.getText() + ",'" + passsignin.getText() + "','" + usersignin.getText().trim()
						+ "','female','" + datesignin.getValue() + "');");

				db.applyOnDataBase("INSERT INTO phonenumber(studentsid,phonenum)  VALUES (" + idsignin.getText()
						+ ",  '" + phonesignin.getText() + "');");

				connect.close();
				Stage stage = (Stage) signinButton.getScene().getWindow();
				stage.getIcons().add(new Image("icon.png"));
				stage.close();

				Stage stage1 = new Stage();
				AnchorPane root1 = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
				stage1.getIcons().add(new Image("icon.png"));
				stage1.setTitle("Basic Interface");
				stage1.setScene(new Scene(root1, 846, 473));
				stage1.show();

			}

		}

	}

}
