package application;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerSentMeeting implements Initializable {

	@FXML
	private Button backBt;

	@FXML
	private Button deleteBt;

	@FXML
	private AnchorPane scenePane;

	private DataBase db;

	@FXML
	private TableView<Meeting> table;

	@FXML
	void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) backBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Basic Interface");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	void delete(ActionEvent event) {
		if (!table.getSelectionModel().isEmpty()) {

			Meeting m = table.getSelectionModel().getSelectedItem();

			if (m.getType().equals("libraries"))
				db.applyOnDataBase("delete from student_Visit_libararies where studentsID = " + m.getStudentId()
						+ " and librariesid = " + m.getId() + " and FromTime = '" + m.getFromTime() + "' and date = '"
						+ m.getDate() + "';");

			else if (m.getType().equals("street"))
				db.applyOnDataBase("delete from student_Visit_Street where studentsID = " + m.getStudentId()
						+ " and streetid = " + m.getId() + " and FromTime = '" + m.getFromTime() + "' and date = '"
						+ m.getDate() + "';");

			else if (m.getType().equals("college"))
				db.applyOnDataBase("delete from student_visit_college where studentsID = " + m.getStudentId()
						+ " and collegeid = " + m.getId() + " and FromTime = '" + m.getFromTime() + "' and date = '"
						+ m.getDate() + "';");

			else
				db.applyOnDataBase("delete from student_visit_cafeteria where studentsID = " + m.getStudentId()
						+ " and cafeteriaid = " + m.getId() + " and FromTime = '" + m.getFromTime() + "' and date = '"
						+ m.getDate() + "';");

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		db = new DataBase();

		table.setEditable(false);

		TableColumn<Meeting, String> studentName = new TableColumn<Meeting, String>("Student Name");
		studentName.setMinWidth(50);
		studentName.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getStudentName()));
		studentName.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> meetingType = new TableColumn<Meeting, String>("Type");
		meetingType.setMinWidth(30);
		meetingType.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getType()));
		meetingType.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> meetingName = new TableColumn<Meeting, String>("Place Name");
		meetingName.setMinWidth(50);
		meetingName.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPlaceName()));
		meetingName.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> from = new TableColumn<Meeting, String>("From Time");
		from.setMinWidth(30);
		from.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getFromTime()));
		from.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> to = new TableColumn<Meeting, String>("To Time");
		to.setMinWidth(30);
		to.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getToTime()));
		to.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> date = new TableColumn<Meeting, String>("Date");
		date.setMinWidth(50);
		date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDate()));
		date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Meeting, String> des = new TableColumn<Meeting, String>("Description");
		des.setMinWidth(50);
		des.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDes()));
		des.setStyle("-fx-alignment: CENTER;");

		ArrayList<Meeting> meets = new ArrayList<>();

		ResultSet rs = db.appyQueryOnDataBase(
				"select studentsID, cafeteriaid, FromTime, ToTime, date, Des  from student_visit_cafeteria where studentsID = "
						+ ControllerLogIn.soso + ";");

		try {
			if (rs != null)
				while (rs.next()) {

					ResultSet rs1 = db.appyQueryOnDataBase(
							"select studentname from students where studentsid = " + rs.getString(1) + ";");
					rs1.next();

					ResultSet rs2 = db.appyQueryOnDataBase(
							"select cafeterianame from cafeteria where cafeteriaid = " + rs.getString(2) + ";");
					rs2.next();

					meets.add(new Meeting(rs1.getString(1), "Cafeteria", rs2.getString(1), rs.getString(3),
							rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(1), rs.getString(2)));

				}

			rs = db.appyQueryOnDataBase(
					"select studentsID, collegeid, FromTime, ToTime, date, Des  from student_visit_college where studentsID = "
							+ ControllerLogIn.soso + ";");

			if (rs != null)
				while (rs.next()) {
					ResultSet rs1 = db.appyQueryOnDataBase(
							"select studentname from students where studentsid = " + rs.getString(1) + ";");
					rs1.next();

					ResultSet rs2 = db.appyQueryOnDataBase(
							"select collegename from college where collegeid = " + rs.getString(2) + ";");
					rs2.next();

					meets.add(new Meeting(rs1.getString(1), "college", rs2.getString(1), rs.getString(3),
							rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(1), rs.getString(2)));

				}
			rs = db.appyQueryOnDataBase(
					"select studentsID, streetid, FromTime, ToTime, date, Des  from student_Visit_Street where studentsID = "
							+ ControllerLogIn.soso + ";");

			if (rs != null)
				while (rs.next()) {
					ResultSet rs1 = db.appyQueryOnDataBase(
							"select studentname from students where studentsid = " + rs.getString(1) + ";");
					rs1.next();

					ResultSet rs2 = db.appyQueryOnDataBase(
							"select streetName from street where streetid = " + rs.getString(2) + ";");
					rs2.next();

					meets.add(new Meeting(rs1.getString(1), "street", rs2.getString(1), rs.getString(3),
							rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(1), rs.getString(2)));

				}
			rs = db.appyQueryOnDataBase(
					"select studentsID, librariesid, FromTime, ToTime, date, Des  from student_Visit_libararies where studentsID = "
							+ ControllerLogIn.soso + ";");

			if (rs != null)
				while (rs.next()) {
					ResultSet rs1 = db.appyQueryOnDataBase(
							"select studentname from students where studentsid = " + rs.getString(1) + ";");
					rs1.next();

					ResultSet rs2 = db.appyQueryOnDataBase(
							"select libname from libraries where librariesid = " + rs.getString(2) + ";");
					rs2.next();

					meets.add(new Meeting(rs1.getString(1), "libraries", rs2.getString(1), rs.getString(3),
							rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(1), rs.getString(2)));

				}
		} catch (NumberFormatException | SQLException e1) {

		}

		ObservableList<Meeting> data = FXCollections.observableArrayList(meets);

		table.setItems(data);
		table.getColumns().setAll(studentName, meetingType, meetingName, from, to, date, des);

	}

}
