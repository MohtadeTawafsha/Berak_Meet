package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerbasicInterface {

	@FXML
	private Button closeBt;

	@FXML
	private Button createBt;

	@FXML
	private Button findBt;

	@FXML
	private Button receivedBt;

	@FXML
	private AnchorPane sceneBasic;

	@FXML
	private Button sentBt;

	@FXML
	private Button updateBt;

	@FXML
	public void close(ActionEvent event) throws IOException {
		Stage stage = (Stage) closeBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("interFace.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Break Meet");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void create(ActionEvent event) throws IOException {
		Stage stage = (Stage) createBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();
		Stage stage1 = new Stage();

		AnchorPane root = FXMLLoader.load(getClass().getResource("createMeet.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Choose your destination");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void find(ActionEvent event) throws IOException {
		Stage stage = (Stage) findBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("findStudent.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Find Meeting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void sent(ActionEvent event) throws IOException {
		Stage stage = (Stage) sentBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("sentMeeting.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Sent Meeting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void received(ActionEvent event) throws IOException {
		Stage stage = (Stage) receivedBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("receivedMessages.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Received Messages");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void update(ActionEvent event) throws IOException {
		Stage stage = (Stage) updateBt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("update.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Update");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void AnchorPane() {

	}

}
