package application;

public class Phone {
	private String num_phone;
	private int id;

	public Phone() {
		super();
	}

	public Phone(int id, String num_phone) {
		super();
		this.id = id;
		this.num_phone = num_phone;
	}

	public Phone(int id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "Phone [ id=" + id + ",num_phone=" + num_phone + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNum_phone() {
		return num_phone;
	}

	public void setNum_phone(String num_phone) {
		this.num_phone = num_phone;
	}

}
