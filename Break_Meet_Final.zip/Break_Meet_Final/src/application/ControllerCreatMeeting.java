package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerCreatMeeting {

	@FXML
	private Button cafbt;

	@FXML
	private Button collegebt;

	@FXML
	private Button libbt;

	@FXML
	private AnchorPane scenePane;

	@FXML
	private Button streetbt;

	@FXML
	private Button btBack;

	@FXML
	void cafeteria(ActionEvent event) throws IOException {
		Stage stage = (Stage) cafbt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("Cafeteria.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Cafeteria Metting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	void college(ActionEvent event) throws IOException {
		Stage stage = (Stage) collegebt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("College.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("College Metting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	void libraries(ActionEvent event) throws IOException {
		Stage stage = (Stage) libbt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("Libraries.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Libraries Metting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	void street(ActionEvent event) throws IOException {
		Stage stage = (Stage) streetbt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("Street.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Street Metting");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) btBack.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Basic Interface");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void AnchorPane() {
	}

}
