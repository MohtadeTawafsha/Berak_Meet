package application;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ControllerLibraries implements Initializable {

	@FXML
	private TextField Description;

	@FXML
	private Button backbt;

	@FXML
	private ComboBox<String> comb;

	@FXML
	private Button creatbt;

	@FXML
	private DatePicker date;

	@FXML
	private TextField fromTime;

	@FXML
	private AnchorPane scenePane;

	@FXML
	private TextField timeTo;

	private DataBase db;

	@FXML
	void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) backbt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("createMeet.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Cafeteria");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	void creat(ActionEvent event) throws IOException {
		String[] tokens = comb.getValue().split(",");
		db.applyOnDataBase("insert into student_Visit_libararies(studentsID,librariesid, FromTime, ToTime, date, Des) "
				+ "value('" + ControllerLogIn.soso + "', " + tokens[0] + ",'" + fromTime.getText() + "', '"
				+ timeTo.getText() + "', '" + date.getValue() + "', '" + Description.getText() + "')");

		Stage stage = (Stage) creatbt.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
		stage.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Basic Interface");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		db = new DataBase();

		ResultSet rs = db.appyQueryOnDataBase("select * from libraries;");

		ArrayList<String> items = new ArrayList<>();
		try {
			while (rs.next())
				items.add(rs.getString(1) + ", " + rs.getString(2));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		comb.setItems(FXCollections.observableArrayList(items));
	}
}
