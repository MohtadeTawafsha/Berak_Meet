package application;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ControllerUpdatesignup implements Initializable {
	@FXML
	private Button backButton;

	@FXML
	private AnchorPane updSignIn;

	@FXML
	private Button updateButton;
	
	@FXML
	private TextField idsignin;

	@FXML
	private TextField usersignin;
	
	@FXML
	private TextField phonesignin;
	
	@FXML
	private ComboBox<String> comboBox;

	@FXML
	private DatePicker datesignin;

	@FXML
	private TextField passsignin;

	@FXML
	Label error1;
	
	boolean check1 = false;

	private DataBase db;

	ObservableList<Student> student = FXCollections.observableArrayList();
	ObservableList<Phone> phone = FXCollections.observableArrayList();

	@FXML
	void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) backButton.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Break Meet");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		db = new DataBase();

		idsignin.setText(ControllerLogIn.soso + "");
		
		ResultSet rsstudent = db
				.appyQueryOnDataBase("select * from students where studentsid = " + ControllerLogIn.soso);

		try {
			while (rsstudent.next()) {
				ResultSet rsphone = db.appyQueryOnDataBase(
						"select * from phonenumber where studentsid=" + ControllerLogIn.soso + ";");

				while (rsphone.next()) {
					phone.add(new Phone(rsphone.getInt(1), rsphone.getString(2)));
					phonesignin.setText(rsphone.getString(2));

				}

				usersignin.setText(rsstudent.getString(3));
				passsignin.setText(rsstudent.getString(2));
				comboBox.setValue(rsstudent.getString(4));
				
				String[] date = rsstudent.getString(5).split("-");
				
				datesignin.setValue(
						LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2])));
				datesignin.isPressed();

				error1.setLayoutX(370);
				error1.setLayoutY(320);
				error1.setTextFill(Color.WHITE);
				check1 = true;

				student.add(new Student(rsstudent.getInt(1), rsstudent.getString(2), rsstudent.getString(3),
						rsstudent.getString(4), rsstudent.getString(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String[] item = { "female", "male" };
		comboBox.setPrefHeight(25);
		comboBox.setLayoutY(197);
		comboBox.setPromptText(" Select The Gender:");
		comboBox.getItems().addAll(item);
	}

	@FXML
	public void AnchorPane() {

	}

	@FXML
	public void sginin() throws IOException, ClassNotFoundException, SQLException {
		if (idsignin.getText() == "") {
			
			error1.setLayoutX(370);
			error1.setLayoutY(320);
			error1.setTextFill(Color.DARKRED);
			error1.setText("error1!! the ID field is empty");

		}

		else if (idsignin.getText() == "" || usersignin.getText() == "" || phonesignin.getText() == ""
				|| passsignin.getText() == "" || comboBox.getValue().isEmpty() || datesignin.getValue().equals(null)) {

			error1.setLayoutX(370);
			error1.setLayoutY(320);
			error1.setTextFill(Color.DARKRED);
			error1.setText("error1!! the some field is empty");

		} else {
			db.applyOnDataBase("update  students set studentname = '" + usersignin.getText() + "' where studentsid = "
					+ idsignin.getText() + ";");
			db.applyOnDataBase("update  students set password = '" + passsignin.getText() + "' where studentsid = "
					+ idsignin.getText() + ";");
			db.applyOnDataBase("update  students set gender = '" + comboBox.getValue() + "' where studentsid = "
					+ idsignin.getText() + ";");
			db.applyOnDataBase("update  students set DOfBarth = '" + datesignin.getValue() + "' where studentsid = "
					+ idsignin.getText() + ";");
			db.applyOnDataBase("update  phonenumber set phonenum = '" + phonesignin.getText() + "' where studentsid = "
					+ idsignin.getText() + ";");

			error1.setLayoutX(370);
			error1.setLayoutY(320);
			error1.setTextFill(Color.WHITE);
			error1.setText("Was Updated: " + idsignin.getText());
		}

	}

}
