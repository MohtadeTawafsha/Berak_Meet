package application;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ControllerLogIn implements Initializable {
	@FXML
	Label error;

	@FXML
	TextField Ueser_ID;

	@FXML
	TextField Password;

	ObservableList<Student> student = FXCollections.observableArrayList();

	@FXML
	private Button logInButton;

	@FXML
	private Hyperlink signInButton;

	@FXML
	private AnchorPane sceneBasic;

	public static String soso;

	@FXML
	void login(ActionEvent event) throws IOException, ClassNotFoundException {
		error.setVisible(false);
		error.setFont(new Font(17));
		student.clear();

		DataBase connection = new DataBase();
		Connection connect = connection.connectDB();

		boolean check = false;

		try {

			String s = "select * from students;";
			Statement stat = connect.createStatement();
			ResultSet rsstudent = stat.executeQuery(s);

			while (rsstudent.next()) {
				if (Password.getText().equals(rsstudent.getString(2))
						&& Ueser_ID.getText().equals(String.valueOf(rsstudent.getInt(1)))) {
					check = true;
				}
				student.add(new Student(rsstudent.getInt(1), rsstudent.getString(2)));
			}

			rsstudent.close();
			stat.close();
			connect.close();

		} catch (Exception E) {

		}

		if (Ueser_ID.getText() == "" || Password.getText() == "") {
			error.setVisible(true);
			error.setLayoutX(540);
			error.setLayoutY(335);
			error.setTextFill(Color.DARKRED);
			error.setText("error!! the some field is empty");

		} else if (check == true) {
			soso = Ueser_ID.getText();
			error.setVisible(false);

			Stage stage = (Stage) logInButton.getScene().getWindow();
			stage.getIcons().add(new Image("icon.png"));
			stage.close();

			Stage stage1 = new Stage();
			AnchorPane root1 = FXMLLoader.load(getClass().getResource("basicInterface.fxml"));
			stage1.setTitle("Basic Interface");
			stage1.getIcons().add(new Image("icon.png"));
			stage1.setScene(new Scene(root1, 846, 473));
			stage1.show();
		} else {

			error.setVisible(true);
			error.setLayoutX(540);
			error.setLayoutY(335);
			error.setTextFill(Color.DARKRED);
			error.setText("error!! Id or password not founded");

		}

	}

	@FXML
	public void siginin() throws IOException {
		Stage stage = (Stage) signInButton.getScene().getWindow();
		stage.getIcons().add(new Image("icon.png"));
		stage.close();

		Stage stage1 = new Stage();
		AnchorPane root = FXMLLoader.load(getClass().getResource("logIn.fxml"));
		stage1.getIcons().add(new Image("icon.png"));
		stage1.setTitle("Sign in");
		stage1.setScene(new Scene(root, 846, 473));
		stage1.show();
	}

	@FXML
	public void AnchorPane() {

	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

}