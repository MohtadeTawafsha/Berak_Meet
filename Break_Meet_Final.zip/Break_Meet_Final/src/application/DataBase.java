package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DataBase {

	private String dbURL;
	private String dbUsername = "root";
	private String dbPassword = "1200262";
	private String URL = "127.0.0.1";
	private String port = "3306";
	private String dbName = "break_meet";
	private Connection con;

	public DataBase() {
		connectDB();
	}

	public Connection connectDB() {
		try {
			dbURL = "jdbc:mysql://" + URL + ":" + port + "/" + dbName + "?verifyServerCertificate=false";
			Properties p = new Properties();
			p.setProperty("user", dbUsername);
			p.setProperty("password", dbPassword);
			p.setProperty("useSSL", "false");
			p.setProperty("autoReconnect", "true");

			con = DriverManager.getConnection(dbURL, p);
			return con;
		} catch (SQLException e) {
			e.printStackTrace();

		}

		return null;
	}

	boolean applyOnDataBase(String string) {//inseet,updaet,delete

		try {
			Statement stmt = con.createStatement();
			boolean rs = stmt.execute(string);
			return rs;
		} catch (Exception e) {
		}
		return false;

	}

	ResultSet appyQueryOnDataBase(String string) {//select

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(string);
			return rs;
		} catch (Exception e) {
		}

		return null;

	}

}
